
# Polymarket Trading CLI — NegRisk Edge Scanner

Scans Polymarket Negative-Risk events, sums best-ask YES baskets, and flags under-round edges. Optional realtime monitor via public market WebSocket.

## Install
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
```

## Usage
```bash
pm-trade scan --threshold 0.005 --min-sets 1
pm-trade watch --threshold 0.005 --min-sets 1
```

### Env (optional)
CLOB_HOST=https://clob.polymarket.com
GAMMA_HOST=https://gamma-api.polymarket.com
WSS_BASE=wss://ws-subscriptions-clob.polymarket.com
# For trading later:
POLY_PRIVATE_KEY=0xYOUR_KEY
POLY_SIGNATURE_TYPE=1
POLY_CHAIN_ID=137
