
import typer
from .scanner import scan_once, watch_loop

app = typer.Typer(no_args_is_help=True, add_completion=False)

@app.command()
def scan(threshold: float = 0.005, min_sets: float = 1.0, slip_margin: float = 0.0):
    """One-shot NegRisk sweep. Prints edges that exceed threshold."""
    rows = scan_once(threshold=threshold, min_sets=min_sets, slip_margin=slip_margin)
    if not rows:
        typer.echo("No edges above threshold.")
        raise typer.Exit(code=0)
    for r in rows:
        typer.echo(r.as_row())

@app.command()
def watch(threshold: float = 0.005, min_sets: float = 1.0, slip_margin: float = 0.0):
    """Realtime NegRisk monitor via public market WebSocket."""
    watch_loop(threshold=threshold, min_sets=min_sets, slip_margin=slip_margin)

if __name__ == "__main__":
    app()
