
from __future__ import annotations
import os, time, typing as t, requests
from dataclasses import dataclass
from py_clob_client.client import ClobClient

GAMMA_HOST = os.getenv("GAMMA_HOST", "https://gamma-api.polymarket.com")

@dataclass(frozen=True)
class EventLite:
    id: str
    slug: str
    neg_risk_fee_bips: int
    markets: t.List[t.Dict[str, t.Any]]

@dataclass(frozen=True)
class MarketTokens:
    yes: str
    no: str
    question: str
    min_tick_size: t.Optional[float]
    min_order_size: t.Optional[float]

def _lower(s: t.Optional[str]) -> str:
    return (s or "").lower()

def _is_placeholder(question: str) -> bool:
    q = _lower(question)
    return ("other" in q) or ("unnamed" in q) or ("tbd" in q)

def fetch_negrisk_events(session: t.Optional[requests.Session] = None, limit: int = 200, active_only: bool = True) -> t.List[EventLite]:
    s = session or requests.Session()
    out: t.List[EventLite] = []
    offset = 0
    while True:
        params = {"limit": limit, "offset": offset, "closed": "false"}
        r = s.get(f"{GAMMA_HOST}/events", params=params, timeout=20)
        r.raise_for_status()
        page = r.json() or []
        if not page:
            break
        for e in page:
            if not e.get("negRisk"):
                continue
            if active_only and not e.get("active", True):
                continue
            markets = e.get("markets", []) or []
            out.append(EventLite(
                id=e["id"],
                slug=e.get("slug", e["id"]),
                neg_risk_fee_bips=int(e.get("negRiskFeeBips") or 0),
                markets=markets,
            ))
        if len(page) < limit:
            break
        offset += limit
        time.sleep(0.05)
    return out

def build_condition_to_tokens(clob: ClobClient) -> t.Dict[str, MarketTokens]:
    cond_to_tokens: t.Dict[str, MarketTokens] = {}
    next_cursor = ""
    while True:
        resp = clob.get_markets(next_cursor=next_cursor)
        data = resp.get("data", []) or []
        for m in data:
            cond = m["condition_id"]
            toks = m.get("tokens", []) or []
            yes_id = next((tkn["token_id"] for tkn in toks if _lower(tkn.get("outcome")) == "yes"), None)
            no_id  = next((tkn["token_id"] for tkn in toks if _lower(tkn.get("outcome")) == "no"), None)
            if not yes_id or not no_id:
                if len(toks) == 2:
                    yes_id = yes_id or toks[0]["token_id"]
                    no_id  = no_id  or toks[1]["token_id"]
                else:
                    continue
            cond_to_tokens[cond] = MarketTokens(
                yes=yes_id,
                no=no_id,
                question=m.get("question", ""),
                min_tick_size=float(m.get("minimum_tick_size")) if m.get("minimum_tick_size") else None,
                min_order_size=float(m.get("minimum_order_size")) if m.get("minimum_order_size") else None,
            )
        next_cursor = resp.get("next_cursor") or "LTE="
        if next_cursor == "LTE=":
            break
    return cond_to_tokens

def yes_tokens_for_event(ev: EventLite, cond_to_tokens: t.Dict[str, MarketTokens], skip_placeholders: bool = True) -> t.List[str]:
    yes_ids: t.List[str] = []
    for mk in ev.markets:
        cond = mk.get("conditionId")
        if not cond:
            continue
        meta = cond_to_tokens.get(cond)
        if not meta:
            continue
        question = mk.get("question") or meta.question or ""
        if skip_placeholders and _is_placeholder(question):
            continue
        yes_ids.append(meta.yes)
    return yes_ids
