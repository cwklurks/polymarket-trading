
from __future__ import annotations
import os, json, typing as t
from dataclasses import dataclass
from websocket import WebSocketApp
from py_clob_client.client import ClobClient
from py_clob_client.clob_types import BookParams
from .markets import fetch_negrisk_events, build_condition_to_tokens, yes_tokens_for_event

CLOB_HOST  = os.getenv("CLOB_HOST",  "https://clob.polymarket.com")
WSS_BASE   = os.getenv("WSS_BASE",   "wss://ws-subscriptions-clob.polymarket.com")  # /ws/market

@dataclass(frozen=True)
class EdgeSignal:
    event_id: str
    slug: str
    k_outcomes: int
    basket_cost: float
    edge: float
    capacity_sets: float
    best_asks: t.Dict[str, float]
    def as_row(self) -> str:
        return f"{self.slug:40s}  k={self.k_outcomes:<2d}  basket={self.basket_cost:.4f}  edge={self.edge*100:5.2f}%  size≈{self.capacity_sets:.2f}"

def _to_float(s):
    if s is None:
        return 0.0
    if isinstance(s, (int, float)):
        return float(s)
    s = str(s).strip()
    return float("0" + s) if s.startswith(".") else float(s)

def _batch_best_asks(client: ClobClient, token_ids: t.List[str]) -> t.Dict[str, float]:
    if not token_ids:
        return {}
    params = [BookParams(token_id=tid, side="BUY") for tid in token_ids]
    resp = client.get_prices(params=params)
    out: t.Dict[str, float] = {}
    for tid, sides in (resp or {}).items():
        price = _to_float(sides.get("BUY"))
        out[tid] = price
    return out

def _top_ask_sizes(client: ClobClient, token_ids: t.List[str]) -> t.Dict[str, float]:
    if not token_ids:
        return {}
    books = client.get_order_books([BookParams(token_id=tid) for tid in token_ids])
    sizes: t.Dict[str, float] = {}
    for b in books or []:
        asks = b.get("asks") or []
        size = _to_float(asks[0]["size"]) if asks else 0.0
        sizes[b["asset_id"]] = size
    return sizes

def _basket_snapshot(client: ClobClient, yes_ids: t.List[str]) -> t.Tuple[float, float, t.Dict[str, float]]:
    best_asks = _batch_best_asks(client, yes_ids)
    basket = sum(best_asks.get(tid, 0.0) for tid in yes_ids)
    top_sizes = _top_ask_sizes(client, yes_ids)
    capacity_sets = min((top_sizes.get(tid, 0.0) for tid in yes_ids), default=0.0)
    return basket, capacity_sets, best_asks

def _edge_from_basket(basket_cost: float, fee_bps: int = 0, slip_margin: float = 0.0) -> float:
    return max(0.0, 1.0 - basket_cost - (fee_bps / 10000.0) - slip_margin)

def scan_once(threshold: float = 0.005, min_sets: float = 1.0, slip_margin: float = 0.0, skip_placeholders: bool = True) -> t.List[EdgeSignal]:
    clob = ClobClient(CLOB_HOST)  # read-only
    events = fetch_negrisk_events()
    cond_map = build_condition_to_tokens(clob)
    findings: t.List[EdgeSignal] = []
    for ev in events:
        yes_ids = yes_tokens_for_event(ev, cond_map, skip_placeholders=skip_placeholders)
        if len(yes_ids) < 2:
            continue
        basket, cap, best_asks = _basket_snapshot(clob, yes_ids)
        edge = _edge_from_basket(basket, fee_bps=ev.neg_risk_fee_bips, slip_margin=slip_margin)
        if edge >= threshold and cap >= min_sets:
            findings.append(EdgeSignal(
                event_id=ev.id, slug=ev.slug, k_outcomes=len(yes_ids),
                basket_cost=basket, edge=edge, capacity_sets=cap, best_asks=best_asks
            ))
    findings.sort(key=lambda r: r.edge, reverse=True)
    return findings

class _EdgeWatch:
    def __init__(self, token_ids: t.List[str], event2tokens: t.Dict[str, t.List[str]], slug_by_event: t.Dict[str, str],
                 fee_bps_by_event: t.Dict[str, int], threshold: float, min_sets: float, slip_margin: float):
        self.token_ids = token_ids
        self.event2tokens = event2tokens
        self.slug_by_event = slug_by_event
        self.fee_bps_by_event = fee_bps_by_event
        self.threshold = threshold
        self.min_sets = min_sets
        self.slip_margin = slip_margin
        self.best_ask: t.Dict[str, float] = {}
        self.last_top_size: t.Dict[str, float] = {}
        self._clob = ClobClient(CLOB_HOST)

    def _recompute_event(self, event_id: str):
        yes_ids = self.event2tokens[event_id]
        if any(tid not in self.best_ask for tid in yes_ids):
            return None
        basket = sum(self.best_ask[tid] for tid in yes_ids)
        missing = [tid for tid in yes_ids if tid not in self.last_top_size]
        if missing:
            self.last_top_size.update(_top_ask_sizes(self._clob, missing))
        cap = min((self.last_top_size.get(tid, 0.0) for tid in yes_ids), default=0.0)
        edge = _edge_from_basket(basket, fee_bps=self.fee_bps_by_event.get(event_id, 0), slip_margin=self.slip_margin)
        if edge >= self.threshold and cap >= self.min_sets:
            return EdgeSignal(
                event_id=event_id, slug=self.slug_by_event[event_id], k_outcomes=len(yes_ids),
                basket_cost=basket, edge=edge, capacity_sets=cap,
                best_asks={tid: self.best_ask[tid] for tid in yes_ids},
            )
        return None

    def on_open(self, ws):
        sub = {"assets_ids": self.token_ids, "type": "market"}
        sub_fallback = {"asset_ids": self.token_ids, "type": "market"}
        try:
            ws.send(json.dumps(sub))
        except Exception:
            ws.send(json.dumps(sub_fallback))

    def on_message(self, ws, message):
        try:
            msg = json.loads(message)
        except Exception:
            return
        et = msg.get("event_type") or msg.get("type")
        if et == "price_change":
            for pc in msg.get("price_changes", []):
                tid = pc.get("asset_id")
                if tid is None:
                    continue
                best_ask = pc.get("best_ask")
                if best_ask is not None:
                    self.best_ask[tid] = _to_float(best_ask)
        elif et == "book":
            tid = msg.get("asset_id")
            asks = msg.get("asks") or []
            if tid and asks:
                self.best_ask[tid] = _to_float(asks[0].get("price"))
                self.last_top_size[tid] = _to_float(asks[0].get("size"))

        if et in ("price_change", "book"):
            touched = set()
            asset_id = msg.get("asset_id")
            if asset_id:
                for eid, tids in self.event2tokens.items():
                    if asset_id in tids:
                        touched.add(eid)
            if et == "price_change":
                for pc in msg.get("price_changes", []):
                    aid = pc.get("asset_id")
                    for eid, tids in self.event2tokens.items():
                        if aid in tids:
                            touched.add(eid)
            for eid in touched:
                sig = self._recompute_event(eid)
                if sig:
                    print(sig.as_row())

    def on_error(self, ws, error):
        print("WSS error:", error)

    def on_close(self, ws, code, reason):
        print("WSS closed:", code, reason)

def watch_loop(threshold: float = 0.005, min_sets: float = 1.0, slip_margin: float = 0.0, skip_placeholders: bool = True) -> None:
    clob = ClobClient(CLOB_HOST)
    events = fetch_negrisk_events()
    cond_map = build_condition_to_tokens(clob)

    event2tokens: t.Dict[str, t.List[str]] = {}
    slug_by_event: t.Dict[str, str] = {}
    fee_bps_by_event: t.Dict[str, int] = {}
    token_ids: t.Set[str] = set()

    for ev in events:
        yes_ids = yes_tokens_for_event(ev, cond_map, skip_placeholders=skip_placeholders)
        if len(yes_ids) < 2:
            continue
        event2tokens[ev.id] = yes_ids
        slug_by_event[ev.id] = ev.slug
        fee_bps_by_event[ev.id] = ev.neg_risk_fee_bips
        token_ids.update(yes_ids)

    ob = _EdgeWatch(
        token_ids=sorted(token_ids),
        event2tokens=event2tokens,
        slug_by_event=slug_by_event,
        fee_bps_by_event=fee_bps_by_event,
        threshold=threshold,
        min_sets=min_sets,
        slip_margin=slip_margin,
    )

    ws = WebSocketApp(
        f"{WSS_BASE}/ws/market",
        on_open=ob.on_open,
        on_message=ob.on_message,
        on_error=ob.on_error,
        on_close=ob.on_close,
    )
    ws.run_forever()
